defmodule CrashgameTest do
  use ExUnit.Case
  doctest Crashgame

  test "greets the world" do
    assert Crashgame.hello() == :world
  end
end
