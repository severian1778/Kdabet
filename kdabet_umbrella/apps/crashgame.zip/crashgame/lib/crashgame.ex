defmodule Crashgame do
  @moduledoc """
  Documentation for `Crashgame`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> Crashgame.hello()
      :world

  """
  def hello do
    :world
  end
end
